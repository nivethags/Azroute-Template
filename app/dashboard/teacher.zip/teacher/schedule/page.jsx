import { ScheduleView } from '@/components/calendar/ScheduleView';
export default function TeacherSchedulePage() {
    return <ScheduleView userType="teacher" />;
  }